/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package setup;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;

/**
 *
 * @author LENOVO
 */
public class DownloadF {
    private String url;
    public DownloadF(String urld) {
        this.url = urld;
    }
    public void setup() throws MalformedURLException, FileNotFoundException, IOException {
        
        URLConnection conn = new URL(url).openConnection();
        InputStream in = conn.getInputStream();
        FileOutputStream out = new FileOutputStream("dvdmania.zip");

        byte[] b = new byte[1024];
        int count;

        while ((count = in.read(b)) >= 0) {
            out.write(b, 0, count);
        }
        out.flush();
        out.close();
        in.close();

        File file = new File("dvdmania.zip");
        if (file.exists()) {
            System.out.println("El archivo se descargó correctamente.");
        } else {
            System.out.println("Hubo un problema al descargar el archivo.");
        }
    }
}

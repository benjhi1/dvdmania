/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package setup;

import java.awt.Color;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


/**
 *
 * @author LENOVO
 */
public class Setup {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Ventana ventana = new Ventana();
        ventana.setLocationRelativeTo(null);
        ventana.getContentPane().setBackground(new Color(70, 24, 30));
        
        ventana.setVisible(true);
    }
    
}
